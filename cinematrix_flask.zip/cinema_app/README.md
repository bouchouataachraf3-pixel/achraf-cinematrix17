# CINEMATRIX — Application Flask (thème cinématique vert & noir)

## Lancer l'application

```bash
cd cinema_app
python -m venv venv
source venv/bin/activate        # Windows : venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Ouvrez http://127.0.0.1:5000 — créez un compte via **Créer un compte**.

## Pages

| URL                       | Description                                   |
|---------------------------|-----------------------------------------------|
| `/login`                  | Connexion (nom d'utilisateur **ou** email)    |
| `/register`               | Inscription (username, email, mot de passe)   |
| `/forgot-password`        | Mot de passe oublié                           |
| `/reset-password/<token>` | Réinitialisation (lien valable 1 h, 1 usage)  |
| `/`                       | Accueil                                       |
| `/contact`                | Contact (messages enregistrés en base)        |
| `/about`                  | À propos                                      |
| `/profile`                | Profil + changement de mot de passe           |

## Mot de passe oublié

Sans SMTP configuré (mode développement), le lien de réinitialisation est
affiché sur la page et dans la console. Pour envoyer de vrais emails :

```bash
export SMTP_HOST=smtp.gmail.com
export SMTP_PORT=587
export SMTP_USER=votre@gmail.com
export SMTP_PASSWORD=mot_de_passe_application
python app.py
```

## Sécurité incluse

- Mots de passe hachés (Werkzeug), jamais stockés en clair
- Protection CSRF sur tous les formulaires POST
- Jeton de réinitialisation signé, expirant et à usage unique
- Message identique que l'email existe ou non (pas de fuite d'information)
- Redirections `next` limitées aux URLs internes

En production : définissez `SECRET_KEY`, utilisez HTTPS et un serveur WSGI (gunicorn).
