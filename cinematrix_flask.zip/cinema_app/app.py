"""
CINEMATRIX - Application Flask avec authentification complète.

Fonctionnalités :
  - Inscription (nom d'utilisateur, email, mot de passe)
  - Connexion (par nom d'utilisateur OU email)
  - Mot de passe oublié -> lien de réinitialisation (valable 1 h, usage unique)
  - Page de réinitialisation du mot de passe
  - Accueil, Contact, À propos, Profil (barre de navigation)
"""
import os
import re
import secrets
import smtplib
import sqlite3
from datetime import datetime
from email.message import EmailMessage
from functools import wraps

from flask import (
    Flask, abort, flash, g, redirect, render_template, request, session, url_for,
)
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")
SECRET_FILE = os.path.join(BASE_DIR, ".secret_key")

RESET_TOKEN_MAX_AGE = 3600  # 1 heure
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")


def load_secret_key() -> str:
    """Clé secrète : variable d'environnement, sinon fichier généré une fois."""
    env_key = os.environ.get("SECRET_KEY")
    if env_key:
        return env_key
    if not os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "w") as f:
            f.write(secrets.token_hex(32))
    with open(SECRET_FILE) as f:
        return f.read().strip()


app = Flask(__name__)
app.config.update(
    SECRET_KEY=load_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
serializer = URLSafeTimedSerializer(app.config["SECRET_KEY"])


# --------------------------------------------------------------------------
# Base de données (SQLite)
# --------------------------------------------------------------------------
def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            bio TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    db.commit()
    db.close()


# --------------------------------------------------------------------------
# Sécurité : CSRF + utilisateur courant
# --------------------------------------------------------------------------
def csrf_token() -> str:
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def protect_and_load_user():
    if request.method == "POST":
        sent = request.form.get("_csrf", "")
        if not sent or not secrets.compare_digest(sent, session.get("_csrf", "")):
            abort(400, "Jeton CSRF invalide. Rechargez la page et réessayez.")
    g.user = None
    uid = session.get("user_id")
    if uid is not None:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        if g.user is None:
            session.clear()


@app.context_processor
def inject_user():
    return {"current_user": g.get("user"), "year": datetime.now().year}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Veuillez vous connecter pour accéder à cette page.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


def safe_next(target: str | None) -> str | None:
    """N'autorise que les redirections internes."""
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return None


def validate_password(pwd: str, confirm: str) -> list[str]:
    errors = []
    if len(pwd) < 8:
        errors.append("Le mot de passe doit contenir au moins 8 caractères.")
    if not re.search(r"[A-Za-z]", pwd) or not re.search(r"\d", pwd):
        errors.append("Le mot de passe doit contenir des lettres et des chiffres.")
    if pwd != confirm:
        errors.append("Les mots de passe ne correspondent pas.")
    return errors


# --------------------------------------------------------------------------
# Envoi d'email (SMTP optionnel)
# --------------------------------------------------------------------------
def send_reset_email(to_email: str, username: str, link: str) -> bool:
    """Envoie l'email via SMTP si configuré. Retourne True si envoyé."""
    host = os.environ.get("SMTP_HOST")
    if not host:
        return False
    msg = EmailMessage()
    msg["Subject"] = "CINEMATRIX - Réinitialisation du mot de passe"
    msg["From"] = os.environ.get("SMTP_FROM", os.environ.get("SMTP_USER", "no-reply@cinematrix.local"))
    msg["To"] = to_email
    msg.set_content(
        f"Bonjour {username},\n\n"
        f"Pour choisir un nouveau mot de passe, ouvrez ce lien (valable 1 heure) :\n{link}\n\n"
        "Si vous n'êtes pas à l'origine de cette demande, ignorez cet email."
    )
    try:
        with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", 587)), timeout=10) as s:
            s.starttls()
            if os.environ.get("SMTP_USER"):
                s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            s.send_message(msg)
        return True
    except Exception as exc:  # noqa: BLE001
        app.logger.error("Échec d'envoi d'email : %s", exc)
        return False


def make_reset_token(user) -> str:
    # Le fragment du hash rend le jeton à usage unique : il devient invalide
    # dès que le mot de passe change.
    return serializer.dumps(
        {"id": user["id"], "h": user["password_hash"][-12:]}, salt="password-reset"
    )


def read_reset_token(token: str):
    try:
        data = serializer.loads(token, salt="password-reset", max_age=RESET_TOKEN_MAX_AGE)
    except (SignatureExpired, BadSignature):
        return None
    user = get_db().execute("SELECT * FROM users WHERE id = ?", (data.get("id"),)).fetchone()
    if user is None or user["password_hash"][-12:] != data.get("h"):
        return None
    return user


# --------------------------------------------------------------------------
# Authentification
# --------------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("home"))
    form = {"username": "", "email": ""}
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        pwd = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        form.update(username=username, email=email)

        errors = []
        if not USERNAME_RE.match(username):
            errors.append("Nom d'utilisateur : 3 à 30 caractères (lettres, chiffres, _ . -).")
        if not EMAIL_RE.match(email):
            errors.append("Adresse email invalide.")
        errors += validate_password(pwd, confirm)

        db = get_db()
        if not errors:
            if db.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
                errors.append("Ce nom d'utilisateur est déjà pris.")
            if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
                errors.append("Cette adresse email est déjà utilisée.")

        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db.execute(
                "INSERT INTO users (username, email, password_hash, created_at) VALUES (?,?,?,?)",
                (username, email, generate_password_hash(pwd), datetime.now().isoformat(timespec="seconds")),
            )
            db.commit()
            flash("Compte créé avec succès. Vous pouvez vous connecter.", "success")
            return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("home"))
    identifier = ""
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        pwd = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE username = ? OR email = ?",
            (identifier, identifier.lower()),
        ).fetchone()
        if user and check_password_hash(user["password_hash"], pwd):
            session.clear()
            session["user_id"] = user["id"]
            if request.form.get("remember"):
                session.permanent = True
            flash(f"Bienvenue, {user['username']} !", "success")
            return redirect(safe_next(request.args.get("next")) or url_for("home"))
        flash("Identifiants incorrects.", "error")
    return render_template("login.html", identifier=identifier)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Vous êtes déconnecté. À bientôt !", "success")
    return redirect(url_for("login"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    dev_link = None
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        if not EMAIL_RE.match(email):
            flash("Adresse email invalide.", "error")
        else:
            user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if user:
                link = url_for("reset_password", token=make_reset_token(user), _external=True)
                if not send_reset_email(user["email"], user["username"], link):
                    # Mode développement : pas de SMTP configuré
                    app.logger.warning("LIEN DE RÉINITIALISATION (%s) : %s", email, link)
                    dev_link = link
            # Même message dans tous les cas : ne révèle pas si l'email existe
            flash(
                "Si un compte existe avec cette adresse, un lien de réinitialisation a été envoyé.",
                "success",
            )
    return render_template("forgot_password.html", dev_link=dev_link)


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    user = read_reset_token(token)
    if user is None:
        flash("Ce lien est invalide ou a expiré. Faites une nouvelle demande.", "error")
        return redirect(url_for("forgot_password"))
    if request.method == "POST":
        errors = validate_password(request.form.get("password", ""), request.form.get("confirm", ""))
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db = get_db()
            db.execute(
                "UPDATE users SET password_hash = ? WHERE id = ?",
                (generate_password_hash(request.form["password"]), user["id"]),
            )
            db.commit()
            flash("Mot de passe réinitialisé. Connectez-vous avec le nouveau.", "success")
            return redirect(url_for("login"))
    return render_template("reset_password.html", token=token)


# --------------------------------------------------------------------------
# Pages principales
# --------------------------------------------------------------------------
@app.route("/")
@login_required
def home():
    return render_template("index.html")


@app.route("/about")
@login_required
def about():
    return render_template("about.html")


@app.route("/contact", methods=["GET", "POST"])
@login_required
def contact():
    form = {"name": g.user["username"], "email": g.user["email"], "subject": "", "body": ""}
    if request.method == "POST":
        form = {k: request.form.get(k, "").strip() for k in ("name", "email", "subject", "body")}
        if not all(form.values()):
            flash("Tous les champs sont obligatoires.", "error")
        elif not EMAIL_RE.match(form["email"]):
            flash("Adresse email invalide.", "error")
        elif len(form["body"]) > 3000:
            flash("Message trop long (3000 caractères max).", "error")
        else:
            db = get_db()
            db.execute(
                "INSERT INTO messages (name,email,subject,body,created_at) VALUES (?,?,?,?,?)",
                (*[form[k] for k in ("name", "email", "subject", "body")],
                 datetime.now().isoformat(timespec="seconds")),
            )
            db.commit()
            flash("Message envoyé. Nous vous répondrons rapidement.", "success")
            return redirect(url_for("contact"))
    return render_template("contact.html", form=form)


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    db = get_db()
    action = request.form.get("action")
    if request.method == "POST" and action == "info":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        bio = request.form.get("bio", "").strip()[:300]
        errors = []
        if not USERNAME_RE.match(username):
            errors.append("Nom d'utilisateur : 3 à 30 caractères (lettres, chiffres, _ . -).")
        if not EMAIL_RE.match(email):
            errors.append("Adresse email invalide.")
        if not errors:
            if db.execute("SELECT 1 FROM users WHERE username=? AND id<>?", (username, g.user["id"])).fetchone():
                errors.append("Ce nom d'utilisateur est déjà pris.")
            if db.execute("SELECT 1 FROM users WHERE email=? AND id<>?", (email, g.user["id"])).fetchone():
                errors.append("Cette adresse email est déjà utilisée.")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db.execute("UPDATE users SET username=?, email=?, bio=? WHERE id=?",
                       (username, email, bio, g.user["id"]))
            db.commit()
            flash("Profil mis à jour.", "success")
        return redirect(url_for("profile"))

    if request.method == "POST" and action == "password":
        if not check_password_hash(g.user["password_hash"], request.form.get("current", "")):
            flash("Mot de passe actuel incorrect.", "error")
        else:
            errors = validate_password(request.form.get("password", ""), request.form.get("confirm", ""))
            if errors:
                for e in errors:
                    flash(e, "error")
            else:
                db.execute("UPDATE users SET password_hash=? WHERE id=?",
                           (generate_password_hash(request.form["password"]), g.user["id"]))
                db.commit()
                flash("Mot de passe modifié.", "success")
        return redirect(url_for("profile"))

    return render_template("profile.html")


@app.errorhandler(400)
@app.errorhandler(404)
def error_page(err):
    return render_template("error.html", error=err), err.code


init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1", host="127.0.0.1", port=5000)
